import matplotlib as mpl        #------For Mac if it crashed------
mpl.use('tkagg')

from mpl_toolkits.mplot3d import Axes3D    # needed for 3d below
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

fig = plt.figure(figsize=(18,15))
ax = fig.add_subplot(111, projection='3d')

df = pd.read_csv('boston.csv')
df = df.drop('Unnamed: 0', axis=1)

ax.scatter(df['LSTAT'], 
           df['RM'], 
           df['MEDV'], 
           color='blue')
    
ax.set_xlabel("LSTAT") 
ax.set_ylabel("RM") 
ax.set_zlabel("MEDV")
plt.show()